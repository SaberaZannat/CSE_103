
#include <stdio.h>
#include <string.h>

#define MAX 100

// Structure
struct Student
{
    int id;
    char name[50];
    int age;
    char department[30];
    int semester;
    float marks;
    char grade[5];
};

// array
struct Student students[MAX];
int count = 0;

// Function to calculate grade
void calculateGrade(struct Student *s)
{
    if (s->marks >= 80)
        strcpy(s->grade, "A+");
    else if (s->marks >= 70)
        strcpy(s->grade, "A");
    else if (s->marks >= 60)
        strcpy(s->grade, "B");
    else if (s->marks >= 50)
        strcpy(s->grade, "C");
    else if (s->marks >= 40)
        strcpy(s->grade, "D");
    else
        strcpy(s->grade, "F");
}

// Function to check duplicate ID
int idExists(int id)
{
    int i;

    for (i = 0; i < count; i++)
    {
        if (students[i].id == id)
            return 1;
    }

    return 0;
}

// Add Student
void addStudent()
{
    if (count >= MAX)
    {
        printf("\nStudent limit reached!\n");
        return;
    }

    printf("\n===== ADD STUDENT =====\n");

    printf("Enter Student ID: ");
    scanf("%d", &students[count].id);

    if (idExists(students[count].id))
    {
        printf("This ID already exists!\n");
        return;
    }

    printf("Enter Student Name: ");
    scanf(" %[^\n]", students[count].name);

    printf("Enter Age: ");
    scanf("%d", &students[count].age);

    printf("Enter Department: ");
    scanf(" %[^\n]", students[count].department);

    printf("Enter Semester: ");
    scanf("%d", &students[count].semester);

    printf("Enter Marks: ");
    scanf("%f", &students[count].marks);

    // Calculate grade
    calculateGrade(&students[count]);

    count++;

    printf("\nStudent added successfully!\n");
}

// Display all students
void displayStudents()
{
    int i;

    if (count == 0)
    {
        printf("\nNo student records found!\n");
        return;
    }

    printf("\n================ ALL STUDENTS ================\n");

    for (i = 0; i < count; i++)
    {
        printf("\nStudent %d\n", i + 1);
        printf("----------------------------------\n");
        printf("ID         : %d\n", students[i].id);
        printf("Name       : %s\n", students[i].name);
        printf("Age        : %d\n", students[i].age);
        printf("Department : %s\n", students[i].department);
        printf("Semester   : %d\n", students[i].semester);
        printf("Marks      : %.2f\n", students[i].marks);
        printf("Grade      : %s\n", students[i].grade);
    }
}

// Search student by ID
void searchStudent()
{
    int id;
    int i;
    int found = 0;

    printf("\n===== SEARCH STUDENT =====\n");

    printf("Enter Student ID: ");
    scanf("%d", &id);

    for (i = 0; i < count; i++)
    {
        if (students[i].id == id)
        {
            printf("\nStudent Found!\n");
            printf("----------------------------------\n");
            printf("ID         : %d\n", students[i].id);
            printf("Name       : %s\n", students[i].name);
            printf("Age        : %d\n", students[i].age);
            printf("Department : %s\n", students[i].department);
            printf("Semester   : %d\n", students[i].semester);
            printf("Marks      : %.2f\n", students[i].marks);
            printf("Grade      : %s\n", students[i].grade);

            found = 1;
            break;
        }
    }

    if (found == 0)
    {
        printf("\nStudent not found!\n");
    }
}

// Update student
void updateStudent()
{
    int id;
    int i;
    int found = 0;

    printf("\n===== UPDATE STUDENT =====\n");

    printf("Enter Student ID: ");
    scanf("%d", &id);

    for (i = 0; i < count; i++)
    {
        if (students[i].id == id)
        {
            printf("\nStudent Found!\n");

            printf("Enter New Name: ");
            scanf(" %[^\n]", students[i].name);

            printf("Enter New Age: ");
            scanf("%d", &students[i].age);

            printf("Enter New Department: ");
            scanf(" %[^\n]", students[i].department);

            printf("Enter New Semester: ");
            scanf("%d", &students[i].semester);

            printf("Enter New Marks: ");
            scanf("%f", &students[i].marks);

            calculateGrade(&students[i]);

            printf("\nStudent updated successfully!\n");

            found = 1;
            break;
        }
    }

    if (found == 0)
    {
        printf("\nStudent not found!\n");
    }
}

// Delete student
void deleteStudent()
{
    int id;
    int i, j;
    int found = 0;

    printf("\n===== DELETE STUDENT =====\n");

    printf("Enter Student ID: ");
    scanf("%d", &id);

    for (i = 0; i < count; i++)
    {
        if (students[i].id == id)
        {
            // Shift elements to the left
            for (j = i; j < count - 1; j++)
            {
                students[j] = students[j + 1];
            }

            count--;

            printf("\nStudent deleted successfully!\n");

            found = 1;
            break;
        }
    }

    if (found == 0)
    {
        printf("\nStudent not found!\n");
    }
}

// Calculate average marks
void calculateAverage()
{
    int i;
    float sum = 0;
    float average;

    if (count == 0)
    {
        printf("\nNo student records available!\n");
        return;
    }

    for (i = 0; i < count; i++)
    {
        sum = sum + students[i].marks;
    }

    average = sum / count;

    printf("\n===== AVERAGE MARKS =====\n");
    printf("Total Students : %d\n", count);
    printf("Average Marks  : %.2f\n", average);
}

// Search student by name
void searchByName()
{
    char name[50];
    int i;
    int found = 0;

    printf("\n===== SEARCH BY NAME =====\n");

    printf("Enter Student Name: ");
    scanf(" %[^\n]", name);

    for (i = 0; i < count; i++)
    {
        if (strcmp(students[i].name, name) == 0)
        {
            printf("\nStudent Found!\n");
            printf("ID         : %d\n", students[i].id);
            printf("Name       : %s\n", students[i].name);
            printf("Department : %s\n", students[i].department);
            printf("Marks      : %.2f\n", students[i].marks);
            printf("Grade      : %s\n", students[i].grade);

            found = 1;
        }
    }

    if (found == 0)
    {
        printf("\nStudent not found!\n");
    }
}

// Save data to file
void saveToFile()
{
    FILE *file;

    file = fopen("students.dat", "wb");

    if (file == NULL)
    {
        printf("\nError opening file!\n");
        return;
    }

    fwrite(&count, sizeof(int), 1, file);

    fwrite(students, sizeof(struct Student), count, file);

    fclose(file);

    printf("\nStudent data saved successfully!\n");
}

// Load data from file
void loadFromFile()
{
    FILE *file;

    file = fopen("students.dat", "rb");

    if (file == NULL)
    {
        // File does not exist yet
        return;
    }

    fread(&count, sizeof(int), 1, file);

    fread(students, sizeof(struct Student), count, file);

    fclose(file);
}

// Main function
int main()
{
    int choice;

    // Load previous student data
    loadFromFile();

    do
    {
        printf("\n\n");
        printf("============================================\n");
        printf("       STUDENT MANAGEMENT SYSTEM\n");
        printf("============================================\n");

        printf("1. Add Student\n");
        printf("2. Display All Students\n");
        printf("3. Search Student by ID\n");
        printf("4. Search Student by Name\n");
        printf("5. Update Student\n");
        printf("6. Delete Student\n");
        printf("7. Calculate Average Marks\n");
        printf("8. Save Data\n");
        printf("9. Exit\n");

        printf("============================================\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                addStudent();
                break;

            case 2:
                displayStudents();
                break;

            case 3:
                searchStudent();
                break;

            case 4:
                searchByName();
                break;

            case 5:
                updateStudent();
                break;

            case 6:
                deleteStudent();
                break;

            case 7:
                calculateAverage();
                break;

            case 8:
                saveToFile();
                break;

            case 9:
                saveToFile();
                printf("\nThank you for using Student Management System!\n");
                break;

            default:
                printf("\nInvalid choice! Please try again.\n");
        }

    } while (choice != 9);

    return 0;
}
